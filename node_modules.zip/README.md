# alexastocks
This is an application for the Amazon Alexa designed to help users find out about current company stock market value.
